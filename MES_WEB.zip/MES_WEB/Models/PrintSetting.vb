﻿Public Class PrintSetting

	Public Property PrinterId As String
	Public Property PrinterName As String

End Class
