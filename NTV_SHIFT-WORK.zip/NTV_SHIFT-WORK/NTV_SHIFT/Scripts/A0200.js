﻿
//番組リストで選択した時
$("#selectBoxBangumi").change(function () {
    var val = this.value
    $('#BANGUMINM').val(val)
});

//内容リストで選択した時
$("#selectBoxNaiyo").change(function () {
    var val = this.value
    $('#NAIYO').val(val)
});

//シフト日と拘束時間追加時
$('#add_btn_sdt').click(function (event) {
    var table = document.getElementById("sdtTable");
    var rows = table.getElementsByTagName("tr");

    var $table = $('#sdtTable');
    var $nrow = $table.find('tr:eq(0)').clone();
    var $ncell = $nrow.find('td:first');

    var $input = $ncell.find('input[name*="EDA"]');
    $input.val(0);
    $input.attr("name", "D0120[" + rows.length + "].EDA");
    $input.attr("id", "D0120_" + rows.length + "__EDA");

    var $input1 = $ncell.find('input[name*="SHIFTYMDST"]');
    $input1.val("");
    $input1.attr("name", "D0120[" + rows.length + "].SHIFTYMDST");
    $input1.attr("id", "D0120_" + rows.length + "__SHIFTYMDST");

    var $input2 = $ncell.find('input[name*="SHIFTYMDED"]');
    $input2.val("");
    $input2.attr("name", "D0120[" + rows.length + "].SHIFTYMDED");
    $input2.attr("id", "D0120_" + rows.length + "__SHIFTYMDED");

    var $input3 = $ncell.find('input[name*="KSKJKNST"]');
    $input3.val("");
    $input3.attr("name", "D0120[" + rows.length + "].KSKJKNST");
    $input3.attr("id", "D0120_" + rows.length + "__KSKJKNST");

    var $input4 = $ncell.find('input[name*="KSKJKNED"]');
    $input4.val("");
    $input4.attr("name", "D0120[" + rows.length + "].KSKJKNED");
    $input4.attr("id", "D0120_" + rows.length + "__KSKJKNED");

    var $span = $ncell.find('div').find('span');
    $span.text("");
    $span.attr("data-valmsg-for", "D0120[" + rows.length + "].SHIFTYMDED")

    $table.append($nrow);

    $('.datepicker').datepicker({
        language: 'ja',
        format: 'yyyy/mm/dd',
        autoclose: true,
        todayHighlight: true,
    });

    $('.time').timepicker({
        showMeridian: false,
        maxHours: 37,
        minuteStep: 5,
        defaultTime: false
    });

    //テーブル行追加されたら、データ変更されたとして、戻るボタンの時メッセージ出す
    var RowCnt = table.rows.length;
    if (RowCnt > 1) {
        $("#myForm").data("MSG", true);

    }
    else {
        $("#myForm").data("MSG", false);
    }

});

//シフト日と拘束時間削除時
$("#sdtTable").on('click', '#del_btn_sdt', function () {

    var table = document.getElementById("sdtTable");
    var rows = table.getElementsByTagName("tr");
   
    if (rows.length != 1) {
        $(this).closest('tr').remove();

        //行削除後、リストのIndexを振り直す
        for (var i = 0; i < rows.length  ; i += 1) {

            var $ncell = $('#sdtTable tr:eq(' + i + ') td:first');

            var $input = $ncell.find('input[name*="EDA"]');
            $input.attr("name", "D0120[" + i + "].EDA");
            $input.attr("id", "D0120_" + i + "__EDA");

            var $input1 = $ncell.find('input[name*="SHIFTYMDST"]');
            $input1.attr("name", "D0120[" + i + "].SHIFTYMDST");
            $input1.attr("id", "D0120_" + i + "__SHIFTYMDST");

            var $input2 = $ncell.find('input[name*="SHIFTYMDED"]');
            $input2.attr("name", "D0120[" + i + "].SHIFTYMDED");
            $input2.attr("id", "D0120_" + i + "__SHIFTYMDED");

            var $input3 = $ncell.find('input[name*="KSKJKNST"]');
            $input3.attr("name", "D0120[" + i + "].KSKJKNST");
            $input3.attr("id", "D0120_" + i + "__KSKJKNST");

            var $input4 = $ncell.find('input[name*="KSKJKNED"]');
            $input4.attr("name", "D0120[" + i + "].KSKJKNED");
            $input4.attr("id", "D0120_" + i + "__KSKJKNED");

        }
    }

    //テーブル行削除されたら、データ変更されたとして、戻るボタンの時メッセージ出す    
       $("#myForm").data("MSG", true);
    
   

});

//担当アナ追加時
$('#add_btn_ana').click(function (event) {
    var table = document.getElementById("anaTable");
    var rows = table.getElementsByTagName("tr");
   
    var $table = $('#anaTable');
    var $nrow = $table.find('tr:eq(0)').clone();
    var $ncell = $nrow.find('td:first');

    var $select = $ncell.find('select[name*="USERID"]');
    $select.val(0);
    $select.attr("name", "D0130[" + rows.length + "].USERID");
    $select.attr("id", "D0130_" + rows.length + "__USERID");

    var $input = $ncell.find('input[name*="EDA"]');
    $input.val(0);
    $input.attr("name", "D0130[" + rows.length + "].EDA");
    $input.attr("id", "D0130_" + rows.length + "__EDA");

    $table.append($nrow);

    //テーブル行追加されたら、データ変更されたとして、戻るボタンの時メッセージ出す
    var RowCnt = table.rows.length;   
    if (RowCnt > 1) {
        $("#myForm").data("MSG", true);

    }
    else {
        $("#myForm").data("MSG", false);
    }
});

//担当アナ削除時
$("#anaTable").on('click', '#del_btn_ana', function () {

    var table = document.getElementById("anaTable");
    var rows = table.getElementsByTagName("tr");
    
    if (rows.length != 1) {
        $(this).closest('tr').remove();

        //行削除後、リストのIndexを振り直す
        for (var i = 0; i < rows.length  ; i += 1) {
            var $ncell = $('#anaTable tr:eq(' + i + ') td:first');

            var $select = $ncell.find('select[name*="USERID"]');
            $select.attr("name", "D0130[" + i + "].USERID")
            $select.attr("id", "D0130_" + i + "__USERID")

            var $input = $ncell.find('input[name*="EDA"]');
            $input.attr("name", "D0130[" + i + "].EDA")
            $input.attr("id", "D0130_" + i + "__EDA")
        }
    }

    //テーブル行削除されたら、データ変更されたとして、戻るボタンの時メッセージ出す      
        $("#myForm").data("MSG", true);
    
});

