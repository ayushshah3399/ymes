﻿Imports System.ComponentModel.DataAnnotations

Public Class A0240ANALIST

	Public Property ITEMNM As String

	Public Property LINKCOLOR As String

	Public Property ITEMCD As String

	Public Property FIX_GYOMNO As String

	Public Property DESKMEMOEXISTFLG As Boolean

	Public Property GYOMDT As String

End Class
