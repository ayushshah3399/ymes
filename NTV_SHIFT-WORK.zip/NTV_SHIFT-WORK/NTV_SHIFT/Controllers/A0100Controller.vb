﻿Imports System.Web.Mvc

Public Class A0100Controller
	Inherits Controller

	' GET: A0100
	Function Index() As ActionResult
		Return View()
	End Function


End Class
