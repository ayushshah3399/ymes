﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Data.Entity.Spatial

<Table("TeLAS.WD0050")>
Partial Public Class WD0050
    <Key>
    <Column(Order:=0)>
    <DatabaseGenerated(DatabaseGeneratedOption.None)>
    Public Property USERID As Short

    <StringLength(12)>
    Public Property USERNM As String

    <Key>
    <Column(Order:=1)>
    <DatabaseGenerated(DatabaseGeneratedOption.None)>
    Public Property NENGETU As Integer

    <StringLength(10)>
    Public Property HI1 As String

    <StringLength(10)>
    Public Property HI2 As String

    <StringLength(10)>
    Public Property HI3 As String

    <StringLength(10)>
    Public Property HI4 As String

    <StringLength(10)>
    Public Property HI5 As String

    <StringLength(10)>
    Public Property HI6 As String

    <StringLength(10)>
    Public Property HI7 As String

    <StringLength(10)>
    Public Property HI8 As String

    <StringLength(10)>
    Public Property HI9 As String

    <StringLength(10)>
    Public Property HI10 As String

    <StringLength(10)>
    Public Property HI11 As String

    <StringLength(10)>
    Public Property HI12 As String

    <StringLength(10)>
    Public Property HI13 As String

    <StringLength(10)>
    Public Property HI14 As String

    <StringLength(10)>
    Public Property HI15 As String

    <StringLength(10)>
    Public Property HI16 As String

    <StringLength(10)>
    Public Property HI17 As String

    <StringLength(10)>
    Public Property HI18 As String

    <StringLength(10)>
    Public Property HI19 As String

    <StringLength(10)>
    Public Property HI20 As String

    <StringLength(10)>
    Public Property HI21 As String

    <StringLength(10)>
    Public Property HI22 As String

    <StringLength(10)>
    Public Property HI23 As String

    <StringLength(10)>
    Public Property HI24 As String

    <StringLength(10)>
    Public Property HI25 As String

    <StringLength(10)>
    Public Property HI26 As String

    <StringLength(10)>
    Public Property HI27 As String

    <StringLength(10)>
    Public Property HI28 As String

    <StringLength(10)>
    Public Property HI29 As String

    <StringLength(10)>
    Public Property HI30 As String

    <StringLength(10)>
    Public Property HI31 As String

    <StringLength(6)>
    Public Property BACKCOLORHI1 As String

    <StringLength(6)>
    Public Property BACKCOLORHI2 As String

    <StringLength(6)>
    Public Property BACKCOLORHI3 As String

    <StringLength(6)>
    Public Property BACKCOLORHI4 As String

    <StringLength(6)>
    Public Property BACKCOLORHI5 As String

    <StringLength(6)>
    Public Property BACKCOLORHI6 As String

    <StringLength(6)>
    Public Property BACKCOLORHI7 As String

    <StringLength(6)>
    Public Property BACKCOLORHI8 As String

    <StringLength(6)>
    Public Property BACKCOLORHI9 As String

    <StringLength(6)>
    Public Property BACKCOLORHI10 As String

    <StringLength(6)>
    Public Property BACKCOLORHI11 As String

    <StringLength(6)>
    Public Property BACKCOLORHI12 As String

    <StringLength(6)>
    Public Property BACKCOLORHI13 As String

    <StringLength(6)>
    Public Property BACKCOLORHI14 As String

    <StringLength(6)>
    Public Property BACKCOLORHI15 As String

    <StringLength(6)>
    Public Property BACKCOLORHI16 As String

    <StringLength(6)>
    Public Property BACKCOLORHI17 As String

    <StringLength(6)>
    Public Property BACKCOLORHI18 As String

    <StringLength(6)>
    Public Property BACKCOLORHI19 As String

    <StringLength(6)>
    Public Property BACKCOLORHI20 As String

    <StringLength(6)>
    Public Property BACKCOLORHI21 As String

    <StringLength(6)>
    Public Property BACKCOLORHI22 As String

    <StringLength(6)>
    Public Property BACKCOLORHI23 As String

    <StringLength(6)>
    Public Property BACKCOLORHI24 As String

    <StringLength(6)>
    Public Property BACKCOLORHI25 As String

    <StringLength(6)>
    Public Property BACKCOLORHI26 As String

    <StringLength(6)>
    Public Property BACKCOLORHI27 As String

    <StringLength(6)>
    Public Property BACKCOLORHI28 As String

    <StringLength(6)>
    Public Property BACKCOLORHI29 As String

    <StringLength(6)>
    Public Property BACKCOLORHI30 As String

    <StringLength(6)>
    Public Property BACKCOLORHI31 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI1 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI2 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI3 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI4 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI5 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI6 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI7 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI8 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI9 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI10 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI11 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI12 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI13 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI14 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI15 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI16 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI17 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI18 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI19 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI20 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI21 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI22 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI23 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI24 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI25 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI26 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI27 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI28 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI29 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI30 As String

    <StringLength(6)>
    Public Property WAKUCOLORHI31 As String

    <StringLength(6)>
    Public Property FONTCOLORHI1 As String

    <StringLength(6)>
    Public Property FONTCOLORHI2 As String

    <StringLength(6)>
    Public Property FONTCOLORHI3 As String

    <StringLength(6)>
    Public Property FONTCOLORHI4 As String

    <StringLength(6)>
    Public Property FONTCOLORHI5 As String

    <StringLength(6)>
    Public Property FONTCOLORHI6 As String

    <StringLength(6)>
    Public Property FONTCOLORHI7 As String

    <StringLength(6)>
    Public Property FONTCOLORHI8 As String

    <StringLength(6)>
    Public Property FONTCOLORHI9 As String

    <StringLength(6)>
    Public Property FONTCOLORHI10 As String

    <StringLength(6)>
    Public Property FONTCOLORHI11 As String

    <StringLength(6)>
    Public Property FONTCOLORHI12 As String

    <StringLength(6)>
    Public Property FONTCOLORHI13 As String

    <StringLength(6)>
    Public Property FONTCOLORHI14 As String

    <StringLength(6)>
    Public Property FONTCOLORHI15 As String

    <StringLength(6)>
    Public Property FONTCOLORHI16 As String

    <StringLength(6)>
    Public Property FONTCOLORHI17 As String

    <StringLength(6)>
    Public Property FONTCOLORHI18 As String

    <StringLength(6)>
    Public Property FONTCOLORHI19 As String

    <StringLength(6)>
    Public Property FONTCOLORHI20 As String

    <StringLength(6)>
    Public Property FONTCOLORHI21 As String

    <StringLength(6)>
    Public Property FONTCOLORHI22 As String

    <StringLength(6)>
    Public Property FONTCOLORHI23 As String

    <StringLength(6)>
    Public Property FONTCOLORHI24 As String

    <StringLength(6)>
    Public Property FONTCOLORHI25 As String

    <StringLength(6)>
    Public Property FONTCOLORHI26 As String

    <StringLength(6)>
    Public Property FONTCOLORHI27 As String

    <StringLength(6)>
    Public Property FONTCOLORHI28 As String

    <StringLength(6)>
    Public Property FONTCOLORHI29 As String

    <StringLength(6)>
    Public Property FONTCOLORHI30 As String

    <StringLength(6)>
    Public Property FONTCOLORHI31 As String

    <StringLength(6)>
    Public Property TENKAIFONTCOLOR As String

 
    Public Property USERSEX As Boolean

    Public Property HYOJJN As Short?

    Public Overridable Property WD0060 As ICollection(Of WD0060)

End Class
