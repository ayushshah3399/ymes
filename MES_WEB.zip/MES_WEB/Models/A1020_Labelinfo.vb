﻿Public Class A1020_Labelinfo

	Public Property label_no As String

End Class
