﻿
$('#myModalShitaHina').on('show.bs.modal', function (event) {
    var modal = $(this);
    var button = $(event.relatedTarget);
    var fmtkbn = button.data("fmtkbn");
    var title = '';
    if (fmtkbn == 1) {
        title = '下書保存確認'
    }
    else if (fmtkbn == 2) {
        title = '雛形保存確認'
    }
    modal.find('.modal-title').text(title);

    var pattern = '';
    var patternchk = $('#PTNFLG').prop("checked");

    if (patternchk) {

        var mon = $('#PTN1').prop("checked");
        var tue = $('#PTN2').prop("checked");
        var wed = $('#PTN3').prop("checked");
        var tur = $('#PTN4').prop("checked");
        var fri = $('#PTN5').prop("checked");
        var sat = $('#PTN6').prop("checked");
        var sun = $('#PTN7').prop("checked");

        //ASI[21 Oct 2019]:for WEEKA and WEEKB
        var weekA = $('#WEEKA').prop("checked");
        var weekB = $('#WEEKB').prop("checked");
        
        if (mon) { pattern = pattern + '［月曜日］'; }
        if (tue) { pattern = pattern + '［火曜日］'; }
        if (wed) { pattern = pattern + '［水曜日］'; }
        if (tur) { pattern = pattern + '［木曜日］'; }
        if (fri) { pattern = pattern + '［金曜日］'; }
        if (sat) { pattern = pattern + '［土曜日］'; }
        if (sun) { pattern = pattern + '［日曜日］'; }

        //ASI[21 Oct 2019]:for WEEKA and WEEKB
        if (weekA) { pattern = pattern + '［A週］'; }
        if (weekB) { pattern = pattern + '［B週］'; }

    }
    else {
        pattern = 'パターンなし';
    }

    modal.find('#ddPATTERN').text(pattern);

    var gyomymd = $('#GYOMYMD').val();
    var gyomymded = $('#GYOMYMDED').val();
    if (gyomymded != '') {
        gyomymd = gyomymd + '～' + gyomymded;
    }
    modal.find('#ddGYOMYMD').text(gyomymd);

    var kskjknst = $('#KSKJKNST').val();
    var kskjkned = $('#KSKJKNED').val();
    if (kskjkned != '') {
        kskjknst = kskjknst + '～' + kskjkned;
    }
    modal.find('#ddKSKJKNST').text(kskjknst);

    var catnm = $('#CATCD option:selected').text();
    modal.find('#ddCATNM').text(catnm);

    var banguminm = $('#BANGUMINM').val();
    modal.find('#ddBANGUMINM').text(banguminm);

    var oajknst = $('#OAJKNST').val();
    var oajkned = $('#OAJKNED').val();
    if (oajknst != '') {
        oajknst = oajknst + '～' + oajkned;
    }
    modal.find('#ddOAJKNST').text(oajknst);

    var naiyo = $('#NAIYO').val();
    modal.find('#ddNAIYO').text(naiyo);

    var basho = $('#BASYO').val();
    modal.find('#ddBASYO').text(basho);

    var bangumitanto = $('#BANGUMITANTO').val();
    modal.find('#ddBANGUMITANTO').text(bangumitanto);

    var bangumirenrk = $('#BANGUMIRENRK').val();
    modal.find('#ddBANGUMIRENRK').text(bangumirenrk);

    var biko = $('#BIKO').val();
    modal.find('#ddBIKO').text(biko);

    var tblAna = document.getElementById("myTable");
    var anarows = tblAna.getElementsByTagName("tr");
    var analist = '';
    var anaidlist = '';
    for (var i = 1; i < anarows.length  ; i += 1) {

        var userid = $('#myTable tr:eq(' + i + ') td:first').find('select:first').val();
        var usernm = $('#myTable tr:eq(' + i + ') td:first').find('select:first option:selected').text();

        if (analist != '') {
            analist = analist + '，';
            anaidlist = anaidlist + '，';
        }


        //if (usernm != 0) {
        analist = analist + usernm;
        anaidlist = anaidlist + userid;


    }

    modal.find('#modalAnalist').text(analist);
    modal.find('#modalAnaidlist').text(anaidlist);

    var tblKariAna = document.getElementById("catTable");
    var anarows = tblKariAna.getElementsByTagName("tr");
    var karianalist = '';
    for (var i = 1; i < anarows.length  ; i += 1) {
        var karianacat = $('#catTable tr:eq(' + i + ') td:first').find('input:first').val();
        if (karianalist != '') {
            karianalist = karianalist + '，';
        }
        karianalist = karianalist + karianacat;
    }

    modal.find('#modalKarianalist').text(karianalist);

});


//下書/雛形保存
$("#modal-save").click(function () {

    $("#errorHinamemo").text("");

    var memo = $('#modalHINAMEMO').val();

    if (memo != '') {
        if (getByteCount(memo) > 30) {

            $("#errorHinamemo").text("文字数がオーバーしています。");
            return false;

        }
    }

    var modal = $(this);

    var hinamemo = $("#modalHINAMEMO").val();
    $('#HINAMEMO').val(hinamemo);

    var datakbn = $("input[name='modalDATAKBN']:checked").val();
    $('#DATAKBN').val(datakbn);

    var anaidlist = $("#modalAnaidlist").text();
    $('#ANAIDLIST').val(anaidlist);

    var karianalist = $("#modalKarianalist").text();
    $('#KARIANALIST').val(karianalist);

    $("#myForm").submit()

});

//アナウンサー選択ダイアログ
$('#myModalAna').on('show.bs.modal', function (event) {

    var modal = $(this);
    var button = $(event.relatedTarget);
    var kbn = button.data('kbn');
    modal.find('#kbn').val(kbn);

    modal.find('.modal-body').load(myApp.Urls.baseUrl + 'A0170/SearchAna?kbn=' + kbn);

    if (kbn == 1) {
        modal.find('.modal-title').text('アナウンサー選択');
    }
    else if (kbn == 2) {
        modal.find('.modal-title').text('仮アナカテゴリー選択');
    }
});

//アナウンサー選択ダイアログ
$('#myModalAna').on('shown.bs.modal', function (e) {

    var kbn = $('#kbn').val();
    var analist = '';

    if (kbn == 1) {
        analist = $('#modalAnalist').text();
    }
    else if (kbn == 2) {
        analist = $('#modalKarianalist').text();
    }

    var tblAna = document.getElementById("tblAna");
    if (tblAna != null) {
        var anarows = tblAna.getElementsByTagName("tr");

        for (var i = 0; i < anarows.length  ; i += 1) {
            var ananm = jQuery.trim($('#tblAna tr:eq(' + i + ') td:eq(1)').text().replace("\n", ""))

            if (analist.indexOf(ananm) != -1) {
                $('#tblAna tr:eq(' + i + ') td:first').find('input:first').prop('checked', true);
            }
        }
    }     

});


//アナウンサー選択クリック
$("#modal-selectana").click(function () {

    var tblAna = document.getElementById("tblAna");
    var anarows = tblAna.getElementsByTagName("tr");
    var analist = '';
    var anaidlist = '';
    for (var i = 0; i < anarows.length  ; i += 1) {
        var chk = $('#tblAna tr:eq(' + i + ') td:first').find('input:first').is(':checked');
        if (chk) {
            var ananm = $('#tblAna tr:eq(' + i + ') td:eq(1)').text()
            var anaid = $('#tblAna tr:eq(' + i + ') td:eq(1)').find('input:first').val()
            if (analist != '') {
                analist = analist + '，';
                anaidlist = anaidlist + '，';
            }
            analist = analist + ananm;
            anaidlist = anaidlist + anaid;
        }
    }

    var kbn = $('#kbn').val();
    if (kbn == 1) {
        $('#modalAnalist').text(analist);
        $('#modalAnaidlist').text(anaidlist);
    }
    else if (kbn == 2) {
        $('#modalKarianalist').text(analist);
    }
});




function pad(str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
}

function getjtjkn(dt, time) {

    var HH = time.substr(0, 2);
    var MM = time.substr(3, 2);

    if (HH >= 24) {
        HH = HH - 24;
        HH = pad(HH, 2)

        var dt = new Date(dt);
        var yy = dt.getFullYear();
        var mm = dt.getMonth() + 1;
        var dd = dt.getDate() + 1;

        dt = yy + "/" + pad(mm, 2) + "/" + pad(dd, 2);
    }

    var jtjkn = dt + " " + HH + ":" + MM;

    return jtjkn;
}


//バイト数取得
function getByteCount(str) {
    var b = str.match(/[^\x00-\xff]/g);
    return (str.length + (!b ? 0 : b.length));
}
