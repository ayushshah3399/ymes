﻿Imports System.Web.Optimization

Public Class MvcApplication
	Inherits System.Web.HttpApplication

	Protected Sub Application_Start()
		AreaRegistration.RegisterAllAreas()
		FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters)
		RouteConfig.RegisterRoutes(RouteTable.Routes)
		BundleConfig.RegisterBundles(BundleTable.Bundles)
	End Sub

	'This is For Language culture Set for Everypage
	Protected Sub Application_BeginRequest(ByVal sender As Object, ByVal e As System.EventArgs)

		Dim Cookie As HttpCookie = HttpContext.Current.Request.Cookies("language")
		Dim datefmt As HttpCookie = HttpContext.Current.Request.Cookies("Cookie_datefmt")
		Dim dateseparator As HttpCookie = HttpContext.Current.Request.Cookies("Cookie_dateseparator")

		'This is ByDefault Culture
		If Cookie Is Nothing Then

			System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("en-US")
			System.Threading.Thread.CurrentThread.CurrentUICulture = New System.Globalization.CultureInfo("en-US")

			System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = "dd.MM.yyyy"
			System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern = "dd.MM.yyyy"
			System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.DateSeparator = "."

			System.Threading.Thread.CurrentThread.CurrentUICulture.DateTimeFormat.ShortDatePattern = "dd.MM.yyyy"
			System.Threading.Thread.CurrentThread.CurrentUICulture.DateTimeFormat.LongDatePattern = "dd.MM.yyyy"
			System.Threading.Thread.CurrentThread.CurrentUICulture.DateTimeFormat.DateSeparator = "."

		Else

			System.Threading.Thread.CurrentThread.CurrentCulture = New System.Globalization.CultureInfo(Cookie.Value)
			System.Threading.Thread.CurrentThread.CurrentUICulture = New System.Globalization.CultureInfo(Cookie.Value)

			System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = datefmt.Value
			System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.LongDatePattern = datefmt.Value
			System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.DateSeparator = dateseparator.Value

			System.Threading.Thread.CurrentThread.CurrentUICulture.DateTimeFormat.ShortDatePattern = datefmt.Value
			System.Threading.Thread.CurrentThread.CurrentUICulture.DateTimeFormat.LongDatePattern = datefmt.Value
			System.Threading.Thread.CurrentThread.CurrentUICulture.DateTimeFormat.DateSeparator = dateseparator.Value


		End If

	End Sub

End Class
