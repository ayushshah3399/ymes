﻿//　修正する場合、jsファイル名を変更するように！！！　※　Clientで最新にならない可能性があるため。


$(document).ready(function () {
    // エラーメッセッジで戻ってきた時、日付に時分秒が付いてしまうため。
    var gyomymd = $('#GYOMYMD').val().substr(0, 10);
    var gyomymded = $('#GYOMYMDED').val().substr(0, 10);
    $('#GYOMYMD').val(gyomymd);
    $('#GYOMYMDED').val(gyomymded);


    // アナ選択時の不適合要因の解消中のページ開く時、候補検索が表示されている場合
    var showkoho = $('#showkoho').val();

    if (showkoho == "True") {

        //業務期間、拘束時間、パターンを変更不可にする
        var kskjknst = $('#KSKJKNST').val();
        var kskjkned = $('#KSKJKNED').val();

        $('#divHidden #GYOMYMD').val(gyomymd);
        $('#divHidden #GYOMYMDED').val(gyomymded);
        $('#divHidden #KSKJKNST').val(kskjknst);
        $('#divHidden #KSKJKNED').val(kskjkned);

        $('#GYOMYMD').prop('disabled', true);
        $('#GYOMYMDED').prop('disabled', true);
        $('#KSKJKNST').prop('disabled', true);
        $('#KSKJKNED').prop('disabled', true);

        var pattern = $('#divPattern #chkPattern').prop("checked");

        if (pattern !== undefined) {

            var mon = $('#checkbox #MON').prop("checked");
            var tue = $('#checkbox #TUE').prop("checked");
            var wed = $('#checkbox #WED').prop("checked");
            var tur = $('#checkbox #TUR').prop("checked");
            var fri = $('#checkbox #FRI').prop("checked");
            var sat = $('#checkbox #SAT').prop("checked");
            var sun = $('#checkbox #SUN').prop("checked");
            var weekA = $('#checkboxAB #WEEKA').prop("checked");
            var weekB = $('#checkboxAB #WEEKB').prop("checked");

            $('input:hidden[name="PATTERN"]').val(pattern);
            $('input:hidden[name="MON"]').val(mon);
            $('input:hidden[name="TUE"]').val(tue);
            $('input:hidden[name="WED"]').val(wed);
            $('input:hidden[name="TUR"]').val(tur);
            $('input:hidden[name="FRI"]').val(fri);
            $('input:hidden[name="SAT"]').val(sat);
            $('input:hidden[name="SUN"]').val(sun);
            $('input:hidden[name="WEEKA"]').val(weekA);
            $('input:hidden[name="WEEKB"]').val(weekB);

            $('#divPattern #chkPattern').prop('disabled', true);
            $('#checkbox #MON').prop('disabled', true);
            $('#checkbox #TUE').prop('disabled', true);
            $('#checkbox #WED').prop('disabled', true);
            $('#checkbox #TUR').prop('disabled', true);
            $('#checkbox #FRI').prop('disabled', true);
            $('#checkbox #SAT').prop('disabled', true);
            $('#checkbox #SUN').prop('disabled', true);
            $('#checkboxAB #WEEKA').prop('disabled', true);
            $('#checkboxAB #WEEKB').prop('disabled', true);
        }

        //選択済のアナを候補一覧で非表示にする
        HideAnaInKoholist();

    }
   
    var msgsuccess = jQuery.trim($('#success').val());
    if (msgsuccess.length > 0) {
        alert(msgsuccess);
        return;
    }

    var msgwarning = jQuery.trim($('#warning').val());

    if (msgwarning.length > 0) {
        var result = confirm(msgwarning);
        if (result == true) {
            $('#CONFIRMMSG').val(true);
            $("#myForm").submit();
        }
        else {
            $('#CONFIRMMSG').val(false);

        }
        return;
    }
    
    //アナ選択時の不適合要因確認画面を表示
    var userid = $('#YOINUSERID').val();
   
    if (userid != "" && userid != "0") {
        $('#myModal').modal('show');
        return;

    } 

});


// 候補検索クリック時
$('#btnSearchKoho').on('click', function (f) {

    var err = '';

    var gyomymd = $('#GYOMYMD').val().substr(0,10);
    var gyomymded = $('#GYOMYMDED').val().substr(0, 10);
    var kskjknst = $('#KSKJKNST').val();
    var kskjkned = $('#KSKJKNED').val();
    var catcd = $('#CATCD :selected').text();
    var banguminm =  $('#BANGUMINM').val();
    var oajknst = $('#OAJKNST').val();
    var oajkned = $('#OAJKNED').val();
    var pattern = $('#divPattern #chkPattern').prop("checked");

    if (pattern !== undefined) {
        var mon = $('#checkbox #MON').prop("checked");
        var tue = $('#checkbox #TUE').prop("checked");
        var wed = $('#checkbox #WED').prop("checked");
        var tur = $('#checkbox #TUR').prop("checked");
        var fri = $('#checkbox #FRI').prop("checked");
        var sat = $('#checkbox #SAT').prop("checked");
        var sun = $('#checkbox #SUN').prop("checked");
        var weekA = $('#checkboxAB #WEEKA').prop("checked");
        var weekB = $('#checkboxAB #WEEKB').prop("checked");
    }
        

    $('.validation-summary-errors').text('');

    var div = document.getElementById('divSummaryError');
    div.innerHTML = ""
    div.style.visibility = 'hidden';

    $('div span[data-valmsg-for="GYOMYMD"]').text("");
    $('div span[data-valmsg-for="GYOMYMDED"]').text("");
    $('div span[data-valmsg-for="KSKJKNST"]').text("");
    $('div span[data-valmsg-for="KSKJKNED"]').text("");
    $('div span[data-valmsg-for="CATCD"]').text("");
    $('div span[data-valmsg-for="BANGUMINM"]').text("");
    $('div span[data-valmsg-for="OAJKNST"]').text("");

    if (catcd == '') {
        err = '1';
        $('div span[data-valmsg-for="CATCD"]').text("カテゴリーが必要です。");
        }

    if(banguminm == '') {
        err = '1';
        $('div span[data-valmsg-for="BANGUMINM"]').text("番組名が必要です。");
        }

    if (oajknst != '' && oajkned != '' && pad(oajknst, 5) > pad(oajkned, 5)) {
        err = '1';
        $('div span[data-valmsg-for="OAJKNST"]').text("OA時間-開始と終了の前後関係が誤っています。");
    }

    if (gyomymd == '') {
        err = '1';
        $('div span[data-valmsg-for="GYOMYMD"]').text('業務期間-開始が必要です。');
    }
    else if (gyomymded != '' && gyomymd > gyomymded) {
        err = '1';
        $('div span[data-valmsg-for="GYOMYMD"]').text('業務期間-開始と終了の前後関係が誤っています。');
    }

    if (kskjknst == '' ) {
        err = '1';
        $('div span[data-valmsg-for="KSKJKNST"]').text("拘束時間-開始が必要です。");
    }
    else if (kskjknst != '' && pad(kskjknst, 5) > '36:00') {
        err = '1';
        $('div span[data-valmsg-for="KSKJKNST"]').text("拘束時間-開始が36時を超えています。");
    }

    if (kskjkned == '') {
        err = '1';
        $('div span[data-valmsg-for="KSKJKNED"]').text("拘束時間-終了が必要です。");
    }
    else if (kskjkned != '' && pad(kskjkned, 5) > '36:00') {
        err = '1';
        $('div span[data-valmsg-for="KSKJKNED"]').text("拘束時間-終了が36時を超えています。");
    }
        
    if ( gyomymd != '' & kskjknst != '' && kskjkned != '' && pad(kskjknst, 5) <= '36:00' && pad(kskjkned, 5) <= '36:00') {
        var gyomymdedtemp = gyomymd;
           
        if (pattern == true) {
            //繰り返し登録の場合
            //開始時間 > 終了時間の場合、開始日+1
            if (pad(kskjknst, 5) > pad(kskjkned, 5)) {
                var dt = new Date(gyomymd);
                var yy = dt.getFullYear();
                var mm = dt.getMonth() + 1;
                var dd = dt.getDate() + 1;
                gyomymdedtemp = yy + "/" + pad(mm, 2) + "/" + pad(dd, 2);
            }            
        }
        else {
            //繰り返し登録なしの場合
            if (gyomymded != '' && gyomymd != gyomymded) {
                gyomymdedtemp = gyomymded;
            }
        }
           
        var jtjknst = getjtjkn(gyomymd, pad(kskjknst, 5));
        var jtjkned = getjtjkn(gyomymdedtemp, pad(kskjkned, 5));

        if (gyomymd <= gyomymdedtemp && jtjknst > jtjkned) {
            err = '1';
            $('div span[data-valmsg-for="KSKJKNST"]').text("拘束時間-開始と終了の前後関係が誤っています。");
        }
    }
        
    if (pattern !== undefined) {

        if (pattern && gyomymded == '') {
            err = '1';
            $('div span[data-valmsg-for="GYOMYMDED"]').text("繰り返し登録の場合、業務期間-終了が必要です。");
        }
        else if (pattern && gyomymd == gyomymded) {
            err = '1';
            $('div span[data-valmsg-for="GYOMYMDED"]').text("繰り返し登録の場合、業務期間-開始と終了に同じ日付は指定できません。");
        }


        if (pattern && mon == false && tue == false && wed == false && tur == false && fri == false && sat == false && sun == false) {
            err = '1';
            $('div span[data-valmsg-for="MON"]').text("繰り返し登録の場合、曜日指定が必要です。");
        }
        else if (pattern && weekA == true && weekB == true) {
            err = '1';
            $('div span[data-valmsg-for="MON"]').text("繰り返し登録の場合、A週とB週を同時に選択することはできません。");
        }
        else {
            $('div span[data-valmsg-for="MON"]').text("");
        }

        var exist = '';
        var ABWeekStartDt = new Date($('#ABWEEKSTARTDT').val());
        if (pattern && gyomymded != '' && (mon || tue || wed || tur || fri || sat || sun)) {
            var gyomymdst = gyomymd;
            var bolIsWeekDay = false;
            while (gyomymdst <= gyomymded) {
                var dtgyomymdst = new Date(gyomymdst);
                var weekday = dtgyomymdst.getDay();

                var diffTime = Math.abs(dtgyomymdst - ABWeekStartDt);
                var diffDays = (diffTime / (1000 * 60 * 60 * 24));

                Math.trunc = Math.trunc || function (x) {
                    if (isNaN(x)) {
                        return NaN;
                    }
                    if (x > 0) {
                        return Math.floor(x);
                    }
                    return Math.ceil(x);
                };

                if (weekA && Math.trunc(diffDays / 7) % 2 == 0) {
                    bolIsWeekDay = true;
                }
                if (weekB && Math.trunc(diffDays / 7) % 2 == 1) {
                    bolIsWeekDay = true;
                }
                if (weekA == false && weekB == false) {
                    bolIsWeekDay = true;
                }

                if (bolIsWeekDay) {
                    if (sun && weekday == 0) { exist = '1'; break; }
                    if (mon && weekday == 1) { exist = '1'; break; }
                    if (tue && weekday == 2) { exist = '1'; break; }
                    if (wed && weekday == 3) { exist = '1'; break; }
                    if (tur && weekday == 4) { exist = '1'; break; }
                    if (fri && weekday == 5) { exist = '1'; break; }
                    if (sat && weekday == 6) { exist = '1'; break; }
                }
                var yy = dtgyomymdst.getFullYear();
                var mm = dtgyomymdst.getMonth() + 1;
                var dd = dtgyomymdst.getDate() + 1;

                gyomymdst = yy + "/" + pad(mm, 2) + "/" + pad(dd, 2);
            }

            if (exist == '') {
                err = '1';
                var div = document.getElementById('divSummaryError');
                div.innerHTML = "<ul><li>業務期間内に指定の曜日が存在しません。</li></ul>"
                div.style.visibility = 'visible';
            }
        }

        if (pattern && gyomymd != '' && gyomymded != '' && kskjknst != '' && kskjkned != '' && exist == '1') {

            if ((mon && tue) || (tue && wed) || (wed && tur) || (tur && fri) || (fri && sat) || (sat && sun) || (sun && mon)) {

                var gyomymdedtemp = gyomymd;

                //開始時間 > 終了時間の場合、開始日+1
                if (pad(kskjknst, 5) > pad(kskjkned, 5)) {
                    var dt = new Date(gyomymd);
                    var yy = dt.getFullYear();
                    var mm = dt.getMonth() + 1;
                    var dd = dt.getDate() + 1;
                    gyomymdedtemp = yy + "/" + pad(mm, 2) + "/" + pad(dd, 2);
                }

                var jtjknst = getjtjkn(gyomymd, pad(kskjknst, 5));
                var jtjkned = getjtjkn(gyomymdedtemp, pad(kskjkned, 5));
                var dt1 = new Date(jtjknst);
                var dt2 = new Date(jtjkned);
                var minute = diff_minutes(dt2, dt1);
                if (minute > 1440) {
                    err = '1';
                    $('div span[data-valmsg-for="KSKJKNST"]').text("パターン曜日が連続している場合、拘束時間の総時間が24時間以内しか入力できません。");
                }
            }
        }
    }


    if (err == '') {
        document.body.style.cursor = 'wait';

        $("#divKoho").html("")

        //処理中です。しばらくお待ちください。。
        var lblInfo = document.getElementById('lblInfo');
        lblInfo.style.visibility = 'visible';
        
        var gyomno = $('#GYOMNO').val();
               
        $('#divHidden #GYOMYMD').val(gyomymd);
        $('#divHidden #GYOMYMDED').val(gyomymded);
        $('#divHidden #KSKJKNST').val(kskjknst);
        $('#divHidden #KSKJKNED').val(kskjkned);

        $('#GYOMYMD').prop('disabled', true);
        $('#GYOMYMDED').prop('disabled', true);
        $('#KSKJKNST').prop('disabled', true);
        $('#KSKJKNED').prop('disabled', true);

        var urlpattern = '';

        if (pattern !== undefined) {

            $('input:hidden[name="PATTERN"]').val(pattern);
            $('input:hidden[name="MON"]').val(mon);
            $('input:hidden[name="TUE"]').val(tue);
            $('input:hidden[name="WED"]').val(wed);
            $('input:hidden[name="TUR"]').val(tur);
            $('input:hidden[name="FRI"]').val(fri);
            $('input:hidden[name="SAT"]').val(sat);
            $('input:hidden[name="SUN"]').val(sun);
            $('input:hidden[name="WEEKA"]').val(weekA);
            $('input:hidden[name="WEEKB"]').val(weekB);

            $('#divPattern #chkPattern').prop('disabled', true)
            $('#checkbox #MON').prop('disabled', true)
            $('#checkbox #TUE').prop('disabled', true)
            $('#checkbox #WED').prop('disabled', true)
            $('#checkbox #TUR').prop('disabled', true)
            $('#checkbox #FRI').prop('disabled', true)
            $('#checkbox #SAT').prop('disabled', true)
            $('#checkbox #SUN').prop('disabled', true)
            $('#checkboxAB #WEEKA').prop('disabled', true)
            $('#checkboxAB #WEEKB').prop('disabled', true)

            urlpattern = '&pattern=' + pattern + '&mon=' + mon + '&tue=' + tue + '&wed=' + wed + '&tur=' + tur + '&fri=' + fri + '&sat=' + sat + '&sun=' + sun + '&weekA=' + weekA + '&weekB=' + weekB;
        }          
        else {
            urlpattern = '&pattern=' + false + '&mon=' + false + '&tue=' + false + '&wed=' + false + '&tur=' + false + '&fri=' + false + '&sat=' + false + '&sun=' + false + '&weekA=' + false + '&weekB=' + false;
        }

        var url = myApp.Urls.baseUrl + 'B0020/SearchKOHO/?gyomno=' + gyomno + '&gyomymd=' + gyomymd + '&gyomymded=' + gyomymded +
                                                        '&kskjknst=' + kskjknst + '&kskjkned=' + kskjkned + urlpattern;

        $("#divKoho").load(url, function (response, status, xhr) {

            if (status == "error") {
                var msg = "読み込みエラーが発生しました: ";
                $("#divKoho").html(url　+ '<br />'+ msg + xhr.status + " " + xhr.statusText);
            }

            else if (status == "success") {
                lblInfo.style.visibility = 'hidden';
                HideAnaInKoholist();

            }
        });
                           

        document.body.style.cursor = 'auto';

    }

})

// 担当アナを候補一覧で非表示にする
function HideAnaInKoholist() {

    var tblAna = document.getElementById("myTable");
    var anarows = tblAna.getElementsByTagName("tr");

    var tblKoho = document.getElementById("tblKoho");
    var kohorows = tblKoho.getElementsByTagName("tr");

    for (var i = 1; i < anarows.length  ; i += 1) {
        var anaid = $('#myTable tr:eq(' + i + ') td:first').find('input:eq(1)').val()

        for (var k = 1; k < kohorows.length  ; k += 1) {
            var userid = $('#tblKoho tr:eq(' + k + ') td:first').find('input:first').val()
            if (userid == anaid) {
                $('#tblKoho tr:eq(' + k + ')').hide();
            }
        }
    }
}

// 再編集クリック時
$('#btnReEdit').on('click', function (e) {

    //$('#GYOMYMD').val('');
    //$('#GYOMYMDED').val('');
    //$('#KSKJKNST').val('');
    //$('#KSKJKNED').val('');

    if (sportShiftFlg == 'True') {
        $('#GYOMYMD').prop('disabled', true)
        $('#GYOMYMDED').prop('disabled', true)
    } else {
        $('#GYOMYMD').prop('disabled', false)
        $('#GYOMYMDED').prop('disabled', false)
    }
    
    $('#KSKJKNST').prop('disabled', false)
    $('#KSKJKNED').prop('disabled', false)
    $('#YOINIDYES').val('');

    var div = document.getElementById('divKoho')
    div.innerHTML = ""

    var div = document.getElementById('checkbox');
    if (div != null) {

        //$('#divPattern #chkPattern').prop('checked', false);
        //$('#checkbox #MON').prop('checked', false);
        //$('#checkbox #TUE').prop('checked', false);
        //$('#checkbox #WED').prop('checked', false);
        //$('#checkbox #TUR').prop('checked', false);
        //$('#checkbox #FRI').prop('checked', false);
        //$('#checkbox #SAT').prop('checked', false);
        //$('#checkbox #SUN').prop('checked', false);

        //div.style.visibility = 'hidden';

        $('#divPattern #chkPattern').prop('disabled', false)
        $('#checkbox #MON').prop('disabled', false)
        $('#checkbox #TUE').prop('disabled', false)
        $('#checkbox #WED').prop('disabled', false)
        $('#checkbox #TUR').prop('disabled', false)
        $('#checkbox #FRI').prop('disabled', false)
        $('#checkbox #SAT').prop('disabled', false)
        $('#checkbox #SUN').prop('disabled', false)
        $('#checkboxAB #WEEKA').prop('disabled', false)
        $('#checkboxAB #WEEKB').prop('disabled', false)
    }

    // アナウンサーをアナウンサー（呼出済）へ移動
    var tblAna = document.getElementById("myTable");
    var rowsAna = tblAna.getElementsByTagName("tr");

    if (rowsAna.length > 1) {

        var tblRefAnalist = document.getElementById("tblRefAnalist");
        var rowsRefana = tblRefAnalist.getElementsByTagName("tr");

        // 移動先の初期化（ヘッダ以外の全行を削除）
        $('#tblRefAnalist').find("tr:gt(0)").remove();

        for (var i = 1; i < rowsAna.length  ; i += 1) {

            var ananame = $('#myTable tr:eq(' + i + ') td:first').find('input:first').val();
            var anaCatLen = $('#myTable tr:eq(' + i + ') td:eq(1)').find('select').length;
            var anaCat;
            if (anaCatLen > 0) {
                anaCat = $('#myTable tr:eq(' + i + ') td:eq(1)').find('select').find('option:selected')["0"].label;
            }
            
            var row = tblRefAnalist.insertRow();
            var rowcount = rowsRefana.length - 2;

            var cell1 = row.insertCell(0);            
            cell1.innerHTML = ananame + '<input id ="RefAnalist_' + rowcount + '_" name ="RefAnalist[' + rowcount + ']" type="hidden" value="' + ananame + '" ></input>';            
            
            if (anaCatLen > 0) {
                var Cell2 = row.insertCell(1);
                Cell2.innerHTML = anaCat + '<input id ="RefCatAnalist_' + rowcount + '_" name ="RefCatAnalist[' + rowcount + ']" type="hidden" value="' + anaCat + '" ></input>';
            }
        }

        $('#myTable').find("tr:gt(0)").remove();
    }
     
    
    // 仮アナカテゴリーを仮アナカテゴリー（呼出済）へ移動
    var tblKariana = document.getElementById("catTable");
    var rowsKariana = tblKariana.getElementsByTagName("tr");

    if (rowsKariana.length > 1) {

        var tblRefKariAnalist = document.getElementById("tblRefKariAnalist");
        var rowsRefKariana = tblRefKariAnalist.getElementsByTagName("tr");

        // 移動先の初期化（ヘッダ以外の全行を削除）
        $('#tblRefKariAnalist').find("tr:gt(0)").remove();

        for (var i = 1; i < rowsKariana.length  ; i += 1) {

            var ananame = $('#catTable tr:eq(' + i + ') td:first').find('input:first').val();
            var anaCatLen = $('#catTable tr:eq(' + i + ') td:eq(1)').find('select').length;
            var anaCat;
            if (anaCatLen > 0) {
                anaCat = $('#catTable tr:eq(' + i + ') td:eq(1)').find('select').find('option:selected')["0"].label;
            }
            var row = tblRefKariAnalist.insertRow();
            var rowcount = rowsRefKariana.length - 2;

            var cell1 = row.insertCell(0);
            cell1.innerHTML = ananame + '<input id ="RefKariAnalist_' + rowcount + '_" name ="RefKariAnalist[' + rowcount + ']" type="hidden" value="' + ananame + '" ></input>';

            if (anaCatLen > 0) {
                var Cell2 = row.insertCell(1);
                Cell2.innerHTML = anaCat + '<input id ="RefCatKariAnalist_' + rowcount + '_" name ="RefCatKariAnalist[' + rowcount + ']" type="hidden" value="' + anaCat + '" ></input>';
            }
        }

        $('#catTable').find("tr:gt(0)").remove();
    }
       

});


// メッセージボックスが表示された時
$('#myModal').on('show.bs.modal', function (event) {
    
   if (event.relatedTarget !== undefined) {
        var button = $(event.relatedTarget);
        var userid = button.data('userid');
        var usernm = button.data('usernm');
        var kariana = button.data('kariana');

        $('#kariana').val(kariana);
    }
    else {
        var userid = $('#YOINUSERID').val();
        var usernm = $('#YOINUSERNM').val();
    }

   $('#userid').val(userid);
   $('#usernm').val(usernm);

    if (userid != "") {

        var url = myApp.Urls.baseUrl + 'B0020/SearchYoinData/?userid=' + userid + '&usernm=' + usernm;

        var yoinidyes = $('#YOINIDYES').val();
        if (yoinidyes != "") {
            url = url + '&yoinidyes=' + yoinidyes;
        }

        var modal = $(this);
        modal.find('.searchresult').load(encodeURI(url));
    }

});


//メッセージボックスで[「はい」をクリックした時
$('#btnYes').on('click', function (e) {

    var id = $('#userid').val();
    var name = $('#usernm').val();
    var kariana = $('#kariana').val();
    var yoinid = $('#yoinid').val();
    var lastyoinflg = $('#lastyoinflg').val();     

    var yoinidyes = $('#YOINIDYES').val();
    if (yoinidyes.length > 0) {
        yoinidyes = yoinidyes + ",";
    }
    yoinidyes = yoinidyes + yoinid ;

    // 「はい」をクリックしたユーザーIDと要因ID
    $('#YOINUSERID').val(id);
    $('#YOINUSERNM').val(name);
    $('#YOINIDYES').val(yoinidyes);

    //var deskmemo = $('#deskmemo').val();
    //var markkyst = $('#markkyst').val();
    //var marksytk = $('#marksytk').val();

    $('#myModal').modal('hide');
    if (sportShiftFlg == undefined) { sportShiftFlg == 'False' }

    // 仮アナ
    if (kariana == 'True') {
        //e.preventDefault();

        var table = document.getElementById("catTable");
        var rows = table.getElementsByTagName("tr");
        var row = table.insertRow();
        var rowcount = rows.length - 2;

        var cell1 = row.insertCell(0);

        //cell1.innerHTML = '<input id ="D0021_' + rowcount + '__ANNACATNM" name ="D0021[' + rowcount + '].ANNACATNM" class="form-control input-sm" type="text" value="' + name + '" list="Karianacat" ></input>' +
        //                  '<input id ="D0021_' + rowcount + '__SEQ" name ="D0021[' + rowcount + '].SEQ" type="hidden" value="0" ></input>';

        var cell1HTML = '<input id ="D0021_' + rowcount + '__ANNACATNM" name ="D0021[' + rowcount + '].ANNACATNM" class="form-control input-sm inputBoxAna" type="text" value="' + name + '" ></input>\n' +
            '<input id ="D0021_' + rowcount + '__SEQ" name ="D0021[' + rowcount + '].SEQ" type="hidden" value="0" ></input>\n' +
            '<select class="form-control input-sm selectBoxAna" onchange="AnnacatSelect(this, \'D0021_' + rowcount + '__ANNACATNM\')">\n';

        //$("#KarianacatList option").each(function () {
        //    cell1HTML = cell1HTML + '<option>' + $(this).text() + '</option>';  
        //});

        $("#KarianacatList").find('option').each(function () {
            //alert($(this).text());
            cell1HTML = cell1HTML + '<option>' + $(this).text() + '</option>\n';
        });

        cell1HTML = cell1HTML + '</select>';
        cell1HTML = cell1HTML + '<span class="field-validation-error text-danger" data-valmsg-replace="true" data-valmsg-for="D0021[' + rowcount + '].ANNACATNM"></span>';
        cell1.innerHTML = cell1HTML;
               

        //ASI[12 Dec 2019]
        if (sportShiftFlg == 'True') {
            var cell2 = row.insertCell(1);
            var $RefAnaKariTblRowCnt = $('#tblRefKariAnalist tr').length;
            var $RefAnaTblRowCnt = $('#tblRefAnalist tr').length;
            var $AnaTblRowCnt = $('#myTable tr').length;            
            var matchRefKariVal = "";

            if ($RefAnaKariTblRowCnt >= rows.length) {
                matchRefKariVal = $('#tblRefKariAnalist tr:eq(' + (rows.length - 1) + ') td:eq(1)').find('input:first').val();
            } else if ($AnaTblRowCnt == 1 && $RefAnaTblRowCnt >= rows.length) {
                matchRefKariVal = $('#tblRefAnalist tr:eq(' + (rows.length - 1) + ') td:eq(1)').find('input:first').val();
            }

            var cell2InnerHTML = '<select class="form-control input-sm selectBoxAnaCol" onchange="AnnaColNmSelect(this, \'D0021_' + rowcount + '__COLNM\')">\n';
            var selectedOptionVal = $("#selectLsM0150AnaCol")[0].value;

            $("#selectLsM0150AnaCol").find('option').each(function () {
                //alert($(this).text());
                if (matchRefKariVal != "" && matchRefKariVal == $(this).text()) {
                    cell2InnerHTML = cell2InnerHTML + '<option value=' + $(this)[0].value + ' selected>' + $(this).text() + '</option>\n';
                    selectedOptionVal = $(this)[0].value;
                } else {
                    cell2InnerHTML = cell2InnerHTML + '<option value=' + $(this)[0].value + '>' + $(this).text() + '</option>\n';
                }                
            });

            cell2InnerHTML = cell2InnerHTML + '</select>';
            cell2InnerHTML = cell2InnerHTML + '<input id ="D0021_' + rowcount + '__COLNM" name ="D0021[' + rowcount + '].COLNM" type="hidden" value=' + selectedOptionVal + ' ></input>';
            cell2InnerHTML = cell2InnerHTML + '<span class="field-validation-error text-danger" data-valmsg-replace="true" data-valmsg-for="D0021[' + rowcount + '].COLNM"></span>';
            cell2.innerHTML = cell2InnerHTML;

            var cell3 = row.insertCell(2);
            cell3.innerHTML = '<a href="#" id="del_btn_ana" class="btn btn-danger btn-xs">削除</a>';
        }
        else {
            var cell2 = row.insertCell(1);
            cell2.innerHTML = '<a href="#" id="del_btn_ana" class="btn btn-danger btn-xs">削除</a>';
        }
        

        // 「はい」をクリックしたユーザーIDと要因IDの初期化
        $('#YOINUSERID').val("");
        $('#YOINUSERNM').val("");
        $('#YOINIDYES').val("");

        return false;

    }
        // アナウンサー
    else {

        if (lastyoinflg == 1) {
            //e.preventDefault();

            var tblKoho = document.getElementById("tblKoho");
            var kohorows = tblKoho.getElementsByTagName("tr");
            var kohorowidx = -1;

            for (var i = 1; i < kohorows.length  ; i += 1) {
                var userid = $('#tblKoho tr:eq(' + i + ') td:first').find('input:first').val()
                if (userid == id) {
                    kohorowidx = i;
                    $('#tblKoho tr:eq(' + i + ')').hide();
                }
            }

            var table = document.getElementById("myTable");
            var rows = table.getElementsByTagName("tr");
            var row = table.insertRow();
            var rowcount = rows.length - 2;

            var cell1 = row.insertCell(0);
            cell1.innerHTML = name +
                '<input id ="D0020_' + rowcount + '__USERNM" name ="D0020[' + rowcount + '].USERNM" type="hidden" value="' + name + '" ></input>' +
                '<input id ="D0020_' + rowcount + '__USERID" name ="D0020[' + rowcount + '].USERID" type="hidden" value="' + id + '" ></input>' +
                '<input id ="D0020_' + rowcount + '__YOINIDYES" name ="D0020[' + rowcount + '].YOINIDYES" type="hidden" value="' + yoinidyes + '" ></input>';

            //ASI[12 Dec 2019]
            if (sportShiftFlg == 'True') {
                var cell2 = row.insertCell(1);
                var $RefAnaKariTblRowCnt = $('#tblRefKariAnalist tr').length;
                var $RefAnaTblRowCnt = $('#tblRefAnalist tr').length;
                var $kariTblRowCnt = $('#catTable tr').length;
                var matchRefKariVal = "";

                if ($RefAnaTblRowCnt >= rows.length ) {
                    matchRefKariVal = $('#tblRefAnalist tr:eq(' + (rows.length - 1) + ') td:eq(1)').find('input:first').val();
                } else if ($kariTblRowCnt == 1 && $RefAnaKariTblRowCnt >= rows.length) {
                    matchRefKariVal = $('#tblRefKariAnalist tr:eq(' + (rows.length - 1) + ') td:eq(1)').find('input:first').val();
                }

                var cell2InnerHTML = '<select class="form-control input-sm selectBoxAnaCol" onchange="AnnaColNmSelect(this, \'D0020_' + rowcount + '__COLNM\')">\n';
                var selectedOptionVal = $("#selectLsM0150AnaCol")[0].value;              

                $("#selectLsM0150AnaCol").find('option').each(function () {
                    //alert($(this).text());
                    if (matchRefKariVal != "" && matchRefKariVal == $(this).text()) {
                        cell2InnerHTML = cell2InnerHTML + '<option value=' + $(this)[0].value + ' selected>' + $(this).text() + '</option>\n';
                        selectedOptionVal = $(this)[0].value;
                    } else {
                        cell2InnerHTML = cell2InnerHTML + '<option value=' + $(this)[0].value + '>' + $(this).text() + '</option>\n';
                    } 
                    
                });

                cell2InnerHTML = cell2InnerHTML + '</select>';
                cell2InnerHTML = cell2InnerHTML + '<input id ="D0020_' + rowcount + '__COLNM" name ="D0020[' + rowcount + '].COLNM" type="hidden" value= ' + selectedOptionVal + '></input>';
                cell2InnerHTML = cell2InnerHTML + '<span class="field-validation-error text-danger" data-valmsg-replace="true" data-valmsg-for="D0020[' + rowcount + '].COLNM"></span>';
                cell2.innerHTML = cell2InnerHTML;

                var cell3 = row.insertCell(2);
                cell3.innerHTML = '<a href="#" id="del_btn_ana" class="btn btn-danger btn-xs">削除</a>';
            }
            else {
                var cell2 = row.insertCell(1);
                cell2.innerHTML = '<a href="#" id="del_btn_ana" class="btn btn-danger btn-xs">削除</a>';
            }

            
    
            //'<input id ="D0020_' + rowcount + '__YOINID" name ="D0020[' + rowcount + '].YOINID" type="hidden" value="' + yoinid + '" ></input>' +
            //'<input id ="D0020_' + rowcount + '__DESKMEMO" name ="D0020[' + rowcount + '].DESKMEMO" type="hidden" value="' + deskmemo + '" ></input>' +
            //'<input id ="D0020_' + rowcount + '__MARKKYST" name ="D0020[' + rowcount + '].MARKKYST" type="hidden" value="' + markkyst + '" ></input>' +
            //'<input id ="D0020_' + rowcount + '__MARKSYTK" name ="D0020[' + rowcount + '].MARKSYTK" type="hidden" value="' + marksytk + '" ></input>' +
            //'<input id ="D0020_' + rowcount + '__ROWIDX" name ="D0020[' + rowcount + '].ROWIDX" type="hidden" value="' + kohorowidx + '" ></input>';

            

            // 「はい」をクリックしたユーザーIDと要因IDの初期化
            $('#YOINUSERID').val("");
            $('#YOINUSERNM').val("");
            $('#YOINIDYES').val("");

           
            if (!(yoinid == "3567" || yoinid == "3567,11" || yoinid == "39,0")) {
                return false;

            }

        }
        //else {
        //    $('#myForm').submit();
        //}
    }
});


//アナウンサー一覧の削除ボタンクリック時
$("#myTable").on('click', '#del_btn_ana', function () {
   

    var table = document.getElementById("myTable");
    var rows = table.getElementsByTagName("tr");
    if (rows.length != 1) {

        var row = $(this).closest('tr');
        //var username = jQuery.trim(row.find('td:first').text());
        
        //var username = row.find('td:first').find('input:first').val();
        var userid = row.find('td:first').find('input:eq(1)').val();

        //var yoinid = row.find('td:first').find('input:eq(2)').val();
        //var deskmemo = row.find('td:first').find('input:eq(3)').val();
        //var markkyst = row.find('td:first').find('input:eq(4)').val();
        //var marksytk = row.find('td:first').find('input:eq(5)').val();
        //var rowidx = row.find('td:first').find('input:last').val();

        $(this).closest('tr').remove();

        //行削除後、リストのIndexを振り直す
        var index = 0;
        for (var i = 1; i < rows.length  ; i += 1) {

            var $inputusernm = $('#myTable tr:eq(' + i + ') td:first').find('input:first');
            var $inputuserid = $('#myTable tr:eq(' + i + ') td:first').find('input:eq(1)');
            var $inputyoinid = $('#myTable tr:eq(' + i + ') td:first').find('input:eq(2)');

            if (sportShiftFlg == 'True') {
                var $inputcolnm = $('#myTable tr:eq(' + i + ') td:nth(1)').find('input:first');
                $inputcolnm.attr("name", "D0020[" + index + "].COLNM");
                $inputcolnm.attr("id", "D0020_" + index + "__COLNM");
            }

            //var $inputyoinid = $('#myTable tr:eq(' + i + ') td:first').find('input:eq(2)');
            //var $inputdeskmemo = $('#myTable tr:eq(' + i + ') td:first').find('input:eq(3)');
            //var $inputmarkkyst = $('#myTable tr:eq(' + i + ') td:first').find('input:eq(4)');
            //var $inputmarksytk = $('#myTable tr:eq(' + i + ') td:first').find('input:eq(5)');
            //var $inputrowidx = $('#myTable tr:eq(' + i + ') td:first').find('input:last');

            $inputusernm.attr("name", "D0020[" + index + "].USERNM");
            $inputusernm.attr("id", "D0020_" + index + "__USERNM");

            $inputuserid.attr("name", "D0020[" + index + "].USERID");
            $inputuserid.attr("id", "D0020_" + index + "__USERID");

            $inputyoinid.attr("name", "D0020[" + index + "].YOINIDYES");
            $inputyoinid.attr("id", "D0020_" + index + "__YOINIDYES");

            //$inputyoinid.attr("name", "D0020[" + index + "].YOINID");
            //$inputyoinid.attr("id", "D0020_" + index + "__YOINID");

            //$inputdeskmemo.attr("name", "D0020[" + index + "].DESKMEMO");
            //$inputdeskmemo.attr("id", "D0020_" + index + "__DESKMEMO");

            //$inputmarkkyst.attr("name", "D0020[" + index + "].MARKKYST");
            //$inputmarkkyst.attr("id", "D0020_" + index + "__MARKKYST");

            //$inputmarksytk.attr("name", "D0020[" + index + "].MARKSYTK");
            //$inputmarksytk.attr("id", "D0020_" + index + "__MARKSYTK");

            //$inputrowidx.attr("name", "D0020[" + index + "].ROWIDX");
            //$inputrowidx.attr("id", "D0020_" + index + "__ROWIDX");
            
            index = index + 1;
        }

        //var useridclassnm = row.find('td:first').find('input:eq(1)').attr('class');

        var tblKoho = document.getElementById("tblKoho");
        //if (tblKoho != null && useridclassnm != 'input-validation-error') {
        if (tblKoho != null ) {

            var kohorows = tblKoho.getElementsByTagName("tr");
            var rowidx = -1;

            /*Write AJAX call to uncheck all yoinId*/
            $.ajax({
                url: ResetYoinUserAjax_url,
                type: "POST",
                data: { userid: userid },
                dataType: 'json',
                cache: false,
                success: function (node) {
                    if (node.success) {
                        for (var i = 1; i < kohorows.length; i += 1) {
                            var id = $('#tblKoho tr:eq(' + i + ') td:first').find('input:first').val()
                            if (userid == id) {
                                rowidx = i;
                                $('#tblKoho tr:eq(' + i + ')').show();
                            }
                        }
                    }
                },
                error: function (node) {
                    alert(node.responseText);
                }
            });

            

            //var rowidxstart = $('#tblKoho tbody tr.yoinid_' + yoinid)[0].rowIndex;
            //alert(rowidxstart);
            //var rowCount = $('#tblKoho tbody tr.yoinid_' + yoinid).length + 1;

            //if (rowidx == -1) {
            //    rowidx = $('#tblKoho tbody tr.yoinid_0').length + 1;

            //    var row = tblKoho.insertRow(rowidx);

            //    var classname = "yoinid_" + yoinid;
            //    $('#tblKoho tr:eq(' + rowidx + ')').addClass(classname);

            //    var cell1 = row.insertCell(0);
            //    var cell2 = row.insertCell(1);
            //    var cell3 = row.insertCell(2);
            //    var cell4 = row.insertCell(3);

            //    cell1.innerHTML = username + '<input name ="$VB$Local_item.USERID" type="hidden" value="' + userid + '" ></input>';

            //    if (markkyst == "True") {
            //        cell2.innerHTML = '<font style="background-color: red;">出</font>';
            //    }

            //    if (marksytk == "True") {
            //        cell3.innerHTML = '<font style="background-color: yellow;">※</font>';

            //    }

            //    var cell4html = '<button class="btn btn-success btn-xs" data-toggle="modal" data-target="#myModal" data-userid="' + userid +
            //                       '" data-usernm="' + username + '" data-yoinid="' + yoinid + '" data-kariana="False" data-deskmemo="' + deskmemo +
            //                       '" data-markkyst="' + markkyst + '" data-marksytk="' + marksytk + '" >選択</button>' +
            //                       ' | <a href="/C0040/Index/' + userid + '" target="_blank">シフト</a>';

            //    if (deskmemo == "True") {
            //        cell4html = cell4html + ' | <a href="/A0200/Create" target="_blank">デスク</a>';

            //    }
            //    cell4.innerHTML = cell4html;

            //}
            
        }

        //アナウンサーテーブルの行が削除されたら、データ変更されたので、戻るボタンの時メッセージ出す
        $("#myForm").data("MSG", true);
       
    }
           
   

});

//仮アナカテゴリー一覧の削除ボタンクリック時
$("#catTable").on('click', '#del_btn_ana', function () {

    var table = document.getElementById("catTable");
    var rows = table.getElementsByTagName("tr");
    if (rows.length != 1) {
        $(this).closest('tr').remove();

        //行削除後、リストのIndexを振り直す
        var index = 0;
        for (var i = 1; i < rows.length  ; i += 1) {
            var $input1 = $('#catTable tr:eq(' + i + ') td:first').find('input:first');
            $input1.attr("name", "D0021[" + index + "].ANNACATNM");
            $input1.attr("id", "D0021_" + index + "__ANNACATNM");

            var $input2 = $('#catTable tr:eq(' + i + ') td:first').find('input:last');
            $input2.attr("name", "D0021[" + index + "].SEQ");
            $input2.attr("id", "D0021_" + index + "__SEQ");

            if (sportShiftFlg == 'True') {
                var $inputcolnm = $('#catTable tr:eq(' + i + ') td:eq(1)').find('input:first');
                $inputcolnm.attr("name", "D0021[" + index + "].COLNM");
                $inputcolnm.attr("id", "D0021_" + index + "__COLNM");
            }
            index = index + 1;
        }

    //仮アナウンサーテーブルの行が削除されたら、データ変更されたので、戻るボタンの時メッセージ出す
        $("#myForm").data("MSG", true);
    }

   
   
});

$('#btnCreateShita').on('click', function (e) {
    // 書式に1:下書を設定
    $('#FMTKBN').val(1)

    if (CheckValues() == false) {
        return false;
    }

});

$('#btnCreateHina').on('click', function (e) {
    // 書式に2:雛形を設定
    $('#FMTKBN').val(2)

    if (CheckValues() == false) {
        return false;
    }
});


function CheckValues() {

    $('div span[data-valmsg-for="IKKATUMEMO"]').text("");
    $('div span[data-valmsg-for="GYOMYMD"]').text("");
    $('div span[data-valmsg-for="GYOMYMDED"]').text("");
    $('div span[data-valmsg-for="KSKJKNST"]').text("");
    $('div span[data-valmsg-for="KSKJKNED"]').text("");
    $('div span[data-valmsg-for="OAJKNST"]').text("");
    $('div span[data-valmsg-for="OAJKNED"]').text("");
    $('div span[data-valmsg-for="PTNFLG"]').text("");
    $('div span[data-valmsg-for="BANGUMINM"]').text("");
    $('div span[data-valmsg-for="NAIYO"]').text("");
    $('div span[data-valmsg-for="BASYO"]').text("");
    $('div span[data-valmsg-for="CATCD"]').text("");
    $('div span[data-valmsg-for="BANGUMITANTO"]').text("");
    $('div span[data-valmsg-for="BANGUMIRENRK"]').text("");
    $('div span[data-valmsg-for="BIKO"]').text("");

    var catcd = $('#CATCD :selected').text();
    var err = '';

    if (catcd == '') {
        err = '1';
        $('div span[data-valmsg-for="CATCD"]').text("カテゴリーが必要です。");
    }
    else {
        $('div span[data-valmsg-for="CATCD"]').text("");
    }

    var banguminm = $('#BANGUMINM').val();
    var naiyo = $('#NAIYO').val();
    var basyo = $('#BASYO').val();
    var bangumitanto = $('#BANGUMITANTO').val();
    var renraku = $('#BANGUMIRENRK').val();
    var memo = $('#BIKO').val();

    var gyomymd = $('#GYOMYMD').val();
    var gyomymded = $('#GYOMYMDED').val();
    var kskjknst = $('#KSKJKNST').val();
    var kskjkned = $('#KSKJKNED').val();

    var oajknst = $('#OAJKNST').val();
    var oajkned = $('#OAJKNED').val();
    var pattern = $('#divPattern #chkPattern').prop("checked");

      

    if (gyomymd != '' && gyomymded != '' && gyomymd > gyomymded) {
        err = '1';
        $('div span[data-valmsg-for="GYOMYMD"]').text('業務期間-開始と終了の前後関係が誤っています。');
    }

    if (kskjknst != '' && pad(kskjknst, 5) > '36:00') {
        err = '1';
        $('div span[data-valmsg-for="KSKJKNST"]').text("拘束時間-開始が36時を超えています。");
    }

    if (kskjkned != '' && pad(kskjkned, 5) > '36:00') {
        err = '1';
        $('div span[data-valmsg-for="KSKJKNED"]').text("拘束時間-終了が36時を超えています。");
    }

    if (oajknst != '' && pad(oajknst, 5) > '36:00') {
        err = '1';
        $('div span[data-valmsg-for="OAJKNST"]').text("OA時間-開始が36時を超えています。");
    }

    if (oajkned != '' && pad(oajkned, 5) > '36:00') {
        err = '1';
        $('div span[data-valmsg-for="OAJKNED"]').text("OA時間-終了が36時を超えています。");
    }

    if (oajknst != '' && oajkned != '' && pad(oajknst, 5) <= '36:00' && pad(oajkned, 5) <= '36:00' && pad(oajknst, 5) > pad(oajkned, 5)) {
        err = '1';
        $('div span[data-valmsg-for="OAJKNST"]').text("OA時間-開始と終了の前後関係が誤っています。");
    }

    if (gyomymd != '' & kskjknst != '' && kskjkned != '' && pad(kskjknst, 5) <= '36:00' && pad(kskjkned, 5) <= '36:00') {
        var gyomymdedtemp = gyomymd;

        if (pattern == true) {
            //繰り返し登録の場合
            //開始時間 > 終了時間の場合、開始日+1
            if (pad(kskjknst, 5) > pad(kskjkned, 5)) {
                var dt = new Date(gyomymd);
                var yy = dt.getFullYear();
                var mm = dt.getMonth() + 1;
                var dd = dt.getDate() + 1;
                gyomymdedtemp = yy + "/" + pad(mm, 2) + "/" + pad(dd, 2);
            }
        }
        else {
            //繰り返し登録なしの場合
            if (gyomymded != '' && gyomymd != gyomymded) {
                gyomymdedtemp = gyomymded;
            }
        }

        var jtjknst = getjtjkn(gyomymd, pad(kskjknst, 5));
        var jtjkned = getjtjkn(gyomymdedtemp, pad(kskjkned, 5));

        if (gyomymd <= gyomymdedtemp && jtjknst > jtjkned) {
            err = '1';
            $('div span[data-valmsg-for="KSKJKNST"]').text("拘束時間-開始と終了の前後関係が誤っています。");
        }
    }



    if (banguminm != '') {

        if (getByteCount(banguminm) > 40) {
            err = '1';
            $('div span[data-valmsg-for="BANGUMINM"]').text("文字数がオーバーしています。");

        }

    }

    if (naiyo != '') {
        if (getByteCount(naiyo) > 40) {
            err = '1';
            $('div span[data-valmsg-for="NAIYO"]').text("文字数がオーバーしています。");

        }
    }

    if (basyo != '') {
        if (getByteCount(basyo) > 40) {
            err = '1';
            $('div span[data-valmsg-for="BASYO"]').text("文字数がオーバーしています。");

        }
    }

    if (bangumitanto != '') {
        if (getByteCount(bangumitanto) > 30) {
            err = '1';
            $('div span[data-valmsg-for="BANGUMITANTO"]').text("文字数がオーバーしています。");

        }
    }


    if (renraku != '') {
        if (getByteCount(renraku) > 30) {
            err = '1';
            $('div span[data-valmsg-for="BANGUMIRENRK"]').text("文字数がオーバーしています。");

        }
    }

    if (memo != '') {
        if (getByteCount(memo) > 30) {
            err = '1';
            $('div span[data-valmsg-for="BIKO"]').text("文字数がオーバーしています。");

        }
    }

    $('#catTable tr').each(function () {
        var i = 1
        $(this).find('span').text("");
        var colValue = $(this).find('input').val();
        if (colValue != undefined && colValue != '') {
            if (getByteCount(colValue) > 12) {
                err = '1';

                $(this).find('span').text("文字数がオーバーしています。");
            }

        }

        var i = i + 1
    });


    if (err == '1') {
        return false;
    }

    return true;
}

$('#myModalShitaHina').on('show.bs.modal', function (event) {
    var modal = $(this);
    var button = $(event.relatedTarget);
    var fmtkbn = button.data("fmtkbn");
    var title = '';
    if (fmtkbn == 1) {
        title = '下書保存確認'
    }
    else if (fmtkbn == 2) {
        title = '雛形保存確認'
    }
    modal.find('.modal-title').text(title);

    var pattern = '';
    var patternchk = $('#divPattern #chkPattern').prop("checked");

    if (patternchk) {

        var mon = $('#checkbox #MON').prop("checked");
        var tue = $('#checkbox #TUE').prop("checked");
        var wed = $('#checkbox #WED').prop("checked");
        var tur = $('#checkbox #TUR').prop("checked");
        var fri = $('#checkbox #FRI').prop("checked");
        var sat = $('#checkbox #SAT').prop("checked");
        var sun = $('#checkbox #SUN').prop("checked");

        /*ASI[24 Oct 2019]:*/
        var weekA = $('#checkboxAB #WEEKA').prop("checked");
        var weekB = $('#checkboxAB #WEEKB').prop("checked");


        if (mon) { pattern = pattern + '［月曜日］'; }
        if (tue) { pattern = pattern + '［火曜日］'; }
        if (wed) { pattern = pattern + '［水曜日］'; }
        if (tur) { pattern = pattern + '［木曜日］'; }
        if (fri) { pattern = pattern + '［金曜日］'; }
        if (sat) { pattern = pattern + '［土曜日］'; }
        if (sun) { pattern = pattern + '［日曜日］'; }

        /*ASI[24 Oct 2019]:*/
        if (weekA) { pattern = pattern + '［A週］'; }
        if (weekB) { pattern = pattern + '［B週］'; }

    }
    else {
        pattern = 'パターンなし';
    }

    modal.find('#ddPATTERN').text(pattern);

    var gyomymd = $('#GYOMYMD').val();
    var gyomymded = $('#GYOMYMDED').val();
    if (gyomymded != '') {
        gyomymd = gyomymd + '～' + gyomymded;
    }
    modal.find('#ddGYOMYMD').text(gyomymd);

    var kskjknst = $('#KSKJKNST').val();
    var kskjkned = $('#KSKJKNED').val();
    if (kskjkned != '') {
        kskjknst = kskjknst + '～' + kskjkned;
    }
    modal.find('#ddKSKJKNST').text(kskjknst);

    var catnm = $('#CATCD option:selected').text();
    modal.find('#ddCATNM').text(catnm);

    var banguminm = $('#BANGUMINM').val();
    modal.find('#ddBANGUMINM').text(banguminm);

    var oajknst = $('#OAJKNST').val();
    var oajkned = $('#OAJKNED').val();
    if (oajknst != '') {
        oajknst = oajknst + '～' + oajkned;
    }
    modal.find('#ddOAJKNST').text(oajknst);

    var naiyo = $('#NAIYO').val();
    modal.find('#ddNAIYO').text(naiyo);

    var basho = $('#BASYO').val();
    modal.find('#ddBASYO').text(basho);

    var bangumitanto = $('#BANGUMITANTO').val();
    modal.find('#ddBANGUMITANTO').text(bangumitanto);

    var bangumirenrk = $('#BANGUMIRENRK').val();
    modal.find('#ddBANGUMIRENRK').text(bangumirenrk);

    var biko = $('#BIKO').val();
    modal.find('#ddBIKO').text(biko);

    var tblAna = document.getElementById("myTable");
    var anarows = tblAna.getElementsByTagName("tr");
    var analist = '';
    var anaidlist = '';
    for (var i = 1; i < anarows.length  ; i += 1) {
        var usernm = $('#myTable tr:eq(' + i + ') td:first').find('input:first').val();
        var userid = $('#myTable tr:eq(' + i + ') td:first').find('input:eq(1)').val();
        if (analist != '') {
            analist = analist + '，';
            anaidlist = anaidlist + '，';
        }
        analist = analist + usernm;
        anaidlist = anaidlist + userid;
    }

    modal.find('#modalAnalist').text(analist);
    modal.find('#modalAnaidlist').text(anaidlist);

    var tblKariAna = document.getElementById("catTable");
    var anarows = tblKariAna.getElementsByTagName("tr");
    var karianalist = '';
    for (var i = 1; i < anarows.length  ; i += 1) {
        var karianacat = $('#catTable tr:eq(' + i + ') td:first').find('input:first').val();
        if (karianalist != '') {
            karianalist = karianalist + '，';
        }
        karianalist = karianalist + karianacat;
    }

    modal.find('#modalKarianalist').text(karianalist);

});


//下書/雛形保存
$("#modal-save").click(function () {

    $("#errorHinamemo").text("");

    var memo = $('#modalHINAMEMO').val();

    if (memo != '') {
        if (getByteCount(memo) > 30) {

            $("#errorHinamemo").text("文字数がオーバーしています。");
            return false;
        }
    }

    var modal = $(this);

    var hinamemo = $("#modalHINAMEMO").val();
    $('#HINAMEMO').val(hinamemo);

    var datakbn = $("input[name='modalDATAKBN']:checked").val();
    $('#DATAKBN').val(datakbn);

    var anaidlist = $("#modalAnaidlist").text();
    $('#ANAIDLIST').val(anaidlist);

    var karianalist = $("#modalKarianalist").text();
    $('#KARIANALIST').val(karianalist);

    $("#myForm").submit()

});

//アナウンサー選択ダイアログ
$('#myModalAna').on('show.bs.modal', function (event) {

    var modal = $(this);
    var button = $(event.relatedTarget);
    var kbn = button.data('kbn');
    modal.find('#kbn').val(kbn);

    modal.find('.modal-body').load(myApp.Urls.baseUrl + 'B0020/SearchAna?kbn=' + kbn);

    if (kbn == 1) {
        modal.find('.modal-title').text('アナウンサー選択');
    }
    else if (kbn == 2) {
        modal.find('.modal-title').text('仮アナカテゴリー選択');
    }
});

//アナウンサー選択ダイアログ
$('#myModalAna').on('shown.bs.modal', function (e) {

    var kbn = $('#kbn').val();
    var analist = '';

    if (kbn == 1) {
        analist = $('#modalAnalist').text();
    }
    else if (kbn == 2) {
        analist = $('#modalKarianalist').text();
    }

    var tblAna = document.getElementById("tblAna");
    if (tblAna != null) {
        var anarows = tblAna.getElementsByTagName("tr");

        for (var i = 0; i < anarows.length  ; i += 1) {
            var ananm = jQuery.trim($('#tblAna tr:eq(' + i + ') td:eq(1)').text().replace("\n", ""))

            if (analist.indexOf(ananm) != -1) {
                $('#tblAna tr:eq(' + i + ') td:first').find('input:first').prop('checked', true);
            }
        }
    }   

});


//アナウンサー選択クリック
$("#modal-selectana").click(function () {

    var tblAna = document.getElementById("tblAna");
    var anarows = tblAna.getElementsByTagName("tr");
    var analist = '';
    var anaidlist = '';
    for (var i = 0; i < anarows.length  ; i += 1) {
        var chk = $('#tblAna tr:eq(' + i + ') td:first').find('input:first').is(':checked');
        if (chk) {
            var ananm = $('#tblAna tr:eq(' + i + ') td:eq(1)').text()
            var anaid = $('#tblAna tr:eq(' + i + ') td:eq(1)').find('input:first').val()
            if (analist != '') {
                analist = analist + '，';
                anaidlist = anaidlist + '，';
            }
            analist = analist + ananm;
            anaidlist = anaidlist + anaid;
        }
    }

    var kbn = $('#kbn').val();
    if (kbn == 1) {
        $('#modalAnalist').text(analist);
        $('#modalAnaidlist').text(anaidlist);
    }
    else if (kbn == 2) {
        $('#modalKarianalist').text(analist);
    }
});


function getjtjkn(dt, time) {

    var HH = time.substr(0, 2);
    var MM = time.substr(3, 2);

    if (HH >= 24) {
        HH = HH - 24;
        HH = pad(HH, 2)

        var dt = new Date(dt);
        var yy = dt.getFullYear();
        var mm = dt.getMonth() + 1;
        var dd = dt.getDate() + 1;

        dt = yy + "/" + pad(mm, 2) + "/" + pad(dd, 2);
    }

    var jtjkn = dt + " " + HH + ":" + MM;

    return jtjkn;
}


function diff_minutes(dt2, dt1) {

    var diff = (dt2.getTime() - dt1.getTime()) / 1000;
    diff /= 60;
    return Math.abs(Math.round(diff));

}

function pad(str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
}

//バイト数取得
function getByteCount(str) {
    var b = str.match(/[^\x00-\xff]/g);
    return (str.length + (!b ? 0 : b.length));
}

////選候補一覧の選択ボタンクリック時
//function myCreateFunction(yoinid, id, name, kariana) {

//    // 仮アナ
//    if (kariana == 'True') {
//        var table = document.getElementById("catTable");
//        var rows = table.getElementsByTagName("tr");
//        var row = table.insertRow();
//        var rowcount = rows.length - 2;

//        var cell1 = row.insertCell(0);
//        var cell2 = row.insertCell(1);

//        cell1.innerHTML = '<input id ="D0021_' + rowcount + '__ANNACATNM" name ="D0021[' + rowcount + '].ANNACATNM" class="form-control input-sm" type="text" value="" list="Karianacat" ></input>'+
//                          '<input id ="D0021_' + rowcount + '__SEQ" name ="D0021[' + rowcount + '].SEQ" type="hidden" value="0" ></input>';
//        cell2.innerHTML = '<a href="#" id="del_btn_ana" class="btn btn-danger btn-xs">削除</a>';
//    }
//        // アナウンサー
//    else {

//        if (yoinid == 0) {
//            //if( confirm ("登録してもよろしいですか？") == false ){
//            //    return
//            //}

//        }

//        var table = document.getElementById("myTable");
//        var rows = table.getElementsByTagName("tr");
//        var row = table.insertRow();
//        var rowcount = rows.length - 2;

//        var cell1 = row.insertCell(0);
//        var cell2 = row.insertCell(1);

//        cell1.innerHTML = name + '<input id ="D0020_' + rowcount + '__USERID" name ="D0020[' + rowcount + '].USERID" type="hidden" value="' + id + '" ></input>';
//        cell2.innerHTML = '<a href="#" id="del_btn_ana" class="btn btn-danger btn-xs">削除</a>';

//        var tblKoho = document.getElementById("tblKoho");
//        var kohorows = tblKoho.getElementsByTagName("tr");

//        for (var i = 1; i < kohorows.length  ; i += 1) {
//            var userid = $('#tblKoho tr:eq(' + i + ') td:first').find('input:first').val()
//            if (userid == id) {
//                $('#tblKoho tr:eq(' + i + ')').remove();
//                break;
//            }
//        }


//    }

//}

