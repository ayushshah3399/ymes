﻿
      

function Shonin(value) {

    var userid = $('#userid').val();
    var name = $('#name').val();
    var showdate = $('#showdate').val();

        $.ajax({
            url: "/B0050/CheckD00040",
            async: false,
            type: "POST",
        dataType: 'json',
        data: { id: value},
               
        cache: false,
        success: function (node) {
            if (node.success) {

                if (node.text!= undefined) {
                    var result = confirm(node.text)
                    if (result == false) {
                        return false
                    }
                    $.ajax({
                        url: "/B0050/UpdateD0060Shonin",
                        type: "POST",
                        dataType: 'json',
                        data: { id: value, name: name, userid: userid, showdate: showdate },
                        cache: false,
                        success: function (response) {
                            //alert(response.Url)
                            window.location.href = response.Url;

                        },
                        error: function () {
                            alert('error')
                        }
                    });
                }
                
                             
               
            //document.location.reload();
        } else {
                alert(node.text);
    }
}
       
});
      
}
 

function Kyaka(value) {

    var userid = $('#userid').val();
    var name = $('#name').val();
    var showdate = $('#showdate').val();
      
    var result = confirm("この申請を却下にします。よろしいですか?")

    if (result == false) {
        return false
    }

    

    $.ajax({
        url: "/B0050/UpdateD0060Kyaka",
        type: "POST",
    dataType: 'json',
    data: { kyuid: value, name: name, userid: userid, showdate: showdate },
    cache: false,
    success: function (response) {
        //alert(response.Url)
        window.location.href = response.Url;

    }
});

}

