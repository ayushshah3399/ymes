﻿Public Class SortingPagingInfo
    Public Property SortField As String
    Public Property SortDirection As String
End Class
